# -物流：
__第一列__：商品类型:判断北京人员需求和量，通过商品量，还有商品的类型（民用和大宗），判断现在北京需求货物，并且与零售业，物流业经相关.

第二列：物流公司配送价格:北京物流价格对比图（同期时间段内物流价格比对图）

第三列：物流时间;各企业的物流配送时间（同期时间段）经行分析交通与物流之间联系，进一步建立与经济的相关性。

第四列：快递公司：疫情前后快递量接受对比，疫情前后快递公司营业额对比

__第五列__：零售业：（疫情期间，批发与零售业逆势加速增长）可能与疫情高发期居民购买防疫用品，食品和日用品的关系。

*第五列*:物流方式：北京地区物流运输情况（交通枢纽）与交通联系，对比同期段运输情况，分析经济损耗。

第七列：骑手工资：骑手，快递员疫情期间工资情况，配送单数反映现在北京与其他各地的交通联系，外卖配送数量间接反映餐饮业。

#交通：
__第一列__：客流量：同期时间来京人员对比，可比对进行判断受灾程度，复工率。

第二列：客流来源方向：来京人员分布判断疫情在其他地区分布，疫情严重程度，

第三列：北京人员流动情况：人员聚集地，聚集量和疫情发生地点热力图对比，然后根据疫情发生地与人口聚集地进行比对，研究隐形影响。

第四列：公共交通运行情况：人流量，判断复工程度，进而判断经济受灾程度

__第五列__：汽车出售行业：疫情对汽车零售业冲击

（我们想法是先确定多一点参数，再具体爬数据的时候根据数据，判断什么数据影响最大，最后给有用的数据相对大的权重，然后论述为什么觉得他有用，在进行方案设计）

（物流业对北京经济影响的论文网址）https://m.baidu.com/from=1020712a/bd_page_type=1/ssid=0/uid=0/pu=sz%401320_480%2Ccuid%4008S8i084HflC8vt3YiHMaguoH8gP8HfSjaHx8jal-886a2t1gu2Ef_uov8jka2tHA%2Ccua%40_a-qiyau2ig-NEqpI5me6NN0v8zka2I4_C218yaN-iqlC%2Ccut%400fStN0tI2i4qavC4gODlPpiL3ur9A%2Cosname%40baiduboxapp%2Cctv%402%2Ccfrom%401014517c%2Ccen%40cuid_cua_cut%2Cc3_aid%40A00-ZOBXTCB76RVMSTTM6376KA5W3HAHPPE7-WNSCZJC2%2Ccsrc%40bdbox_tserch_txt%2Cta%40zbios_2_10.0_6_11.20%2Cusm%403%2Cvmgdb%400020100228y/baiduid=eb3ffe90d9f990eade8f6ac82292e3cc/w=0_10_/t=zbios/l=1/tc?ref=www_zbios&lid=5196906098195307447&order=1&fm=alop&isAtom=1&waplogo=1&is_baidu=0&tj=www_normal_1_0_10_title&vit=osres&waput=7&cltj=normal_title&asres=1&title=%E5%8C%97%E4%BA%AC%E5%B8%82%E7%89%A9%E6%B5%81%E4%B8%9A%E5%AF%B9%E7%BB%8F%E6%B5%8E%E5%8F%91%E5%B1%95%E7%9A%84%E5%BD%B1%E5%93%8D%E7%A0%94%E7%A9%B6_%E5%9B%BE%E6%96%87_%E7%99%BE%E5%BA%A6%E6%96%87%E5%BA%93&clk_info=%7B%22tplname%22%3A%22www_normal%22%2C%22ivkType%22%3A%22xcx%22%7D&wd=&eqid=481f1e8fd9fe1bb7100000005e6af656&w_qd=IlPT2AEptyoA_yk5w4Ud5Oyw2U2Okpgpv6wXgAzTuRYsS3A5MFVduGXfaO7&bdver=2&tcplug=1&dict=-1&sec=2018&di=87a592bbc6646e44&bdenc=1&tch=124.1319.264.99.0.0&nsrc=F5H4zVBoagm%2BOIygmTaLM%2FbLEI5sVRC%2F7qBc05CGv5NyVxI8zPI8B33UxhE7GbbY2IOxlvBfMtgHCLI09ZiSSm7C9nvtxzIPyS8qP3ly1u4%3D
